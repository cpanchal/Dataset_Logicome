#https://www.youtube.com/watch?v=P-WYkSZp9lY
folder <- "C:\Users\cpanchal\Desktop\GitHub Code Material"
setwd(folder)

library(ISLR)
library(psych)
library(aod)
library(QuantPsyc)
library(nnet)
library(gtools)
library(ggplot2)
library(dplyr)
library(plyr)
library(compare)
library(magrittr)
library(tidyr)
library(pdist)
library("clusterSim")

# In this code we have perform 100 iterations for the fixed ration. The function "TrainValidationData" returns Training and Test data
# generated for the given categories. After performing all the iterations for different rations we choose 30th set of 60:40.



#-----------------------------------------------------------------------------
######################  Fuction returns Training and Valdiatin sets. 
#-----------------------------------------------------------------------------


TrainValidationData <- function(cat1,cat2,cat3,cat4,Ratio_t)
{
  TrainingDfCat1<-cat1[sample(nrow(cat1), as.integer(nrow(cat1)*Ratio_t)), ]
  TrainingDfCat1$Class <- factor(TrainingDfCat1$Class)
  
  TrainingDfCat2<-cat2[sample(nrow(cat2), as.integer(nrow(cat2)*Ratio_t)), ]
  TrainingDfCat2$Class <- factor(TrainingDfCat2$Class)
  
  TrainingDfCat3<-cat3[sample(nrow(cat3), as.integer(nrow(cat3)*Ratio_t)), ]
  TrainingDfCat3$Class <- factor(TrainingDfCat3$Class)
  
  TrainingDfCat4<-cat4[sample(nrow(cat4), as.integer(nrow(cat4)*Ratio_t)), ]
  TrainingDfCat4$Class <- factor(TrainingDfCat4$Class)
  
  Training<-rbind(TrainingDfCat1,TrainingDfCat2,TrainingDfCat3,TrainingDfCat4)
  Training$Class <- factor(Training$Class)
  
  TestDfCat1<-cat1[!(cat1$Samples %in% TrainingDfCat1$Samples),]
  TestDfCat1$Class <- factor(TestDfCat1$Class)
  
  TestDfCat2<-cat2[!(cat2$Samples %in% TrainingDfCat2$Samples),]
  TestDfCat2$Class <- factor(TestDfCat2$Class)
  
  
  TestDfCat3<-cat3[!(cat3$Samples %in% TrainingDfCat3$Samples),]
  TestDfCat3$Class <- factor(TestDfCat3$Class)
  
  TestDfCat4<-cat4[!(cat4$Samples %in% TrainingDfCat4$Samples),]
  TestDfCat4$Class <- factor(TestDfCat4$Class)
  
  Testing<-rbind(TestDfCat1,TestDfCat2,TestDfCat3,TestDfCat4)
  Testing$Class <- factor(Testing$Class)
  
#  write.csv2(Training,"TrainingSet.csv",row.names = FALSE)
#  write.csv2(Testing,"TestingSet.csv",row.names = FALSE)
  
  names(Training)[names(Training) == "Class"] <- "Class"
  names(Testing)[names(Testing) == "Class"] <- "Class"
  
  
  return(list("Train" = Training,"Test"=Testing))
}

 
 
#----------------------------------------------------------------------------------------------------------------------------
######################  Function to generate disjoin sets.
#----------------------------------------------------------------------------------------------------------------------------

DisjontSets <- function(Dataset,ClassCol){
  
  
  Levels <- levels(Dataset[[ClassCol]])
  LevelList <- list()
  t <- list()
  tt <- list()
  
  for(i in 1:length(Levels)){
    
    LevelList[[i]] <- Dataset[which(Dataset[paste0(ClassCol)] == Levels[[i]]),]
    t[[i]] <- lapply( LevelList[[i]][,3:ncol( LevelList[[i]])-1],as.numeric)
    tt[[i]]<-as.matrix(do.call(rbind,  t[[i]]))
  }
  
  # Using scale function and finding maximum distance from the zero matrix.
  # Understanding scale() function from here: http://stackoverflow.com/questions/20256028/understanding-scale-in-r
   
  
  zeroVector <- data.frame(zeros = t(rep(0, 11)))
  
  FullResult <- as.matrix(pdist(Dataset[,3:ncol(Dataset)-1],zeroVector))
  minDist <- min(FullResult)
  maxDist <- max(FullResult)
  
  
  # Removing the identical samples from the data. We compare two categories and find identical samples.
  # To remove the samples we choose the category having less identical samples.
  
  
  sink("SimilarColumnsScaledData.txt")
  
  epsi <- 0.01
  
  print(paste0("In the data the rows are  samples and genes are columns.The following result shows which rows are similar in the given two categories. Similarity threshold is  ", 
          epsi*100,"% max_dist.", " Here the max_dist is max distance of the data points from the zero vector."))
  print(" ")
  print(paste0("The maximum distance is : ",maxDist,  " and we multiply it with the epsilon :" , epsi, " It becomes, ",
                 maxDist*epsi, " and we calculate pairwise euclidean distance and in these categories we check all the sample having distance less than " ,  maxDist*epsi))
  
  
  combResult <- list()
  PmatrixList <- list()
  combMatrix <- t(combn(length(Levels), 2))
  
  NewLevelList <- LevelList
  rowID <- list()
  colName1 <- list()
  
  for(i in 1:nrow(combMatrix))
  {
    comb <- list()
    Result <- Inf
    res <- NULL
    m <- 0
    cat("\n")
    comb <-combMatrix[i,]
    print(paste0(" Similarities found in the categories: ",comb[1]," and ",comb[2]))
    
    #cat("\n",comb[1],comb[2], "\n","\n")
    
    while(any(is.infinite(Result)))
    {
      Result <- as.matrix(pdist(t(tt[[comb[1]]]),t(tt[[comb[2]]])))
    }
    
    PmatrixList[[i]] <- Result
    
    # print(Result)
    m <-  maxDist  #min(Result) # minDist
   
    #res<-which(((1-epsi)*m <= Result) & ((1+epsi)*m >= Result) , arr.ind = TRUE)
    res<-which((Result <= (epsi)*m )  , arr.ind = TRUE)
    
    #  print("The result is: ")
    #  print(res)
    
    df<- data.frame(res)
    colnames(df) <- c(paste0(comb[1]),paste0(comb[2]))
    print(df)
    combResult[[i]] <- df
    cat("\n")
    
    if(nrow(combResult[[i]])!=0)
    {
      
      # for(c in 1:ncol(combResult[[j]])) {
      # ind <- lapply(combResult, function(j) {as.numeric(colnames(i))})
      ind <- as.numeric(colnames(combResult[[i]]))
      print(ind)
      # print(c)
      
      for(id in 1:length(ind)) {
        rowID[[id]] <- unique(c(combResult[[i]][,which(colnames(combResult[[i]]) == ind[id])]))
        colName1[[id]] <- ind[id]
        # get the samples from "tt"
        # NewLevelList[[ind[[j]][i]]] <- LevelList[[ind[[j]][i]]][-c(rowID[[i]]),]
      }
     
      
      SampleClassCol <- which.min(unlist(lapply(rowID[sapply(rowID,length)>0],length)))
      
      for(i in 1:length(SampleClassCol)){
        ClassColID <- colName1[[SampleClassCol[[i]] ]]
        NewLevelList[[ClassColID]] <- LevelList[[ClassColID]][-c(rowID[[SampleClassCol[[i]]]]),]
      }
      
      # Here we are selecting a column with minimum number of samples.
      
      #minSampleClassCol <- which.min(unlist(lapply(rowID[sapply(rowID,length)>0],length)))
      # ClassColID <- colName1[[minSampleClassCol]]
      # NewLevelList[[ClassColID]] <- LevelList[[ClassColID]][-c(rowID[[minSampleClassCol]]),]
      # 
      # maxSampleClassCol <- which.max(unlist(lapply(rowID[sapply(rowID,length)>0],length)))
      # ClassColIDmax <- colName1[[maxSampleClassCol]]
      # NewLevelList[[ClassColIDmax]] <- LevelList[[ClassColIDmax]][-c(rowID[[maxSampleClassCol]]),]
      # 
      
    }
    
  }
  sink()
  return(NewLevelList)
  
}


#-----------------------------------------------------------------------------
######################  Generate all possible subsets. 
#--------------------------------------- --------------------------------------


powerset = function(s){
  len = length(s)
  l = vector(mode="list",length=2^len) ; l[[1]]=numeric()
  counter = 1L
  for(x in 1L:length(s)){
    for(subset in 1L:counter){
      counter=counter+1L
      l[[counter]] = c(l[[subset]],s[x])
    }
  }
  return(l)
}

#-----------------------------------------------------------------------------------
###################### Function generates Model of Multinomial logistic regression
# and returns predicted results. 
#-----------------------------------------------------------------------------------


MultinomFun <- function(TrainingData, DiseaseColumn, ValidationData, GeneList) {
  
  
  TrainingData$output <- as.numeric(c(DiseaseColumn))
  
  # TrainingData$NumberedClass <-  c(factor(TrainingData$Class))
  # ValidationData$Testutput<- as.numeric(c(DiseaseColumn))
  # data$out <- relevel(data$NumberedDisease,ref = 1)
  # TrainingDatasetsModel<- multinom(output~MMP1+MYO1B+LAPTM4B+MAL+KRT4+MYO10+SPP1+EXT1+HPGD+MGST2+AIM1, TrainingData, MaxNwts = 15000)
  # xnam <- paste(colnames(TrainingDatasets)[3:ncol(TrainingDatasets)-1], sep="") 
  
  fmla <- as.formula(paste("DiseaseColumn ~ ", paste(GeneList, collapse= "+")))
  TrainingDatasetsModel<- multinom(fmla, TrainingData, MaxNwts = 15000)
  PredictedResultProbes<-format(signif(predict(TrainingDatasetsModel, data.frame(ValidationData), type = "probs"), digits = 3),quotes = FALSE)
  ValidationData$predicted<- predict(TrainingDatasetsModel, data.frame(ValidationData), type = "class")
 
   return(list("ValidationData"=ValidationData,"TrainingDatasetsModel"=TrainingDatasetsModel,"PredictedResult"=PredictedResultProbes))  
 
}

#-----------------------------------------------------------------------------------
###################### Binarizing the data.
#-----------------------------------------------------------------------------------



Bindata<- function(Datasets,startInd,endInd) {
  SubsetData<-Datasets[,startInd:endInd]
  print(ncol(SubsetData))
  print(nrow(SubsetData))
  for(i in 1:ncol(SubsetData)) {
    MedianCol <- median(SubsetData[,i])
    print(MedianCol)
    for(j in 1:nrow(SubsetData)) {
      print(SubsetData[j,i])
      if(SubsetData[j,i]<= MedianCol){
        SubsetData[j,i] <- 0
      }else{
        SubsetData[j,i] <- 1
      }
    }
  }
  Binarised <- Datasets
  Binarised[,startInd:endInd]<- SubsetData
  return(Binarised)
}

#-----------------------------------------------------------------------------------
###################### Calculating accuracy of each subset.
#-----------------------------------------------------------------------------------

SubsetAccuracyFile <- function(genePowerset,genesDataframe,n,TrainingDatasets,TestingDatasets) {
  
  df_total = data.frame()
  
  for (i in 1:length(genePowerset)) {
    tempGene <- list()
    if (length(genePowerset[i][[1]]) == n)
    {
      #subsetID<- list()
      subsetID <- genePowerset[i][[1]]
      print(subsetID)
      print(length(subsetID))
      
      tempGene <- paste(genesDataframe$genes[c(subsetID)], sep = "")
      print(tempGene)
     
      res <-  MultinomFun(TrainingDatasets, TrainingDatasets$Class,TestingDatasets,tempGene)
      resAccu <- res$ValidationData
      length(which(resAccu$Class == resAccu$predicted))
      
      # Unbinarised data
      # resA<-MultinomFun(TrainingDatasets,TrainingDatasets$Class,TestingDatasets[,3:ncol(TestingDatasets)-1],tempGene)
      # resA$Class <-  TestingDatasets$Class
      # resA$NumberedClass <-  c(factor(TestingDatasets$Class))
      # length(which(resA$NumberedClass == resA$predicted))
      # length(which(resA$Numbered == resA$predicted))
      
      result <- resAccu # Assign a result to resA or res.
      
      comparisition_matrix <-  ftable(result$predicted, result$Class)
      accuracy <-    100 * (sum(diag(comparisition_matrix)) / length(result$predicted))
      print("Accuracy")
      print(accuracy)
      df <- data.frame(accuracy, t(tempGene))
      df_total <- rbind(df_total, df)
      
      #df<- data.frame(Accuracy =accuracy,GeneList = str(t(tempGene)))
      #resAccur <- rbind(resAccur, df)
      #write.csv( data.frame(accuracy,paste(tempGene)),file = "result.csv", append = TRUE)
    }
  }
  
 # Resfilename <- paste0("ResultSubsetLength",n,".csv")
  # df_total$C <- paste0(colnames(df_total[,c(which(colnames(df_total)!=accuracy))]), sep=',')
 # write.csv2(df_total,file = Resfilename)
 
   C <- df_total[,2:ncol(df_total)]
  write.csv(C,"C.csv")
  C <- read.table("C.CSV",header = TRUE)
  C[,1]<- NULL
  D<-data.frame(df_total[,1],C)
  file.remove("C.csv")
  
  CombColsResfilename <- paste0("CombColsResfilename",n,".csv")
  colnames(D) <- c("accuracy","Subset")
  write.csv2(D,file = CombColsResfilename)
 
  return(df_total)
  
}

#-----------------------------------------------------------------------------------
###################### Collecting the signature for each category
#-----------------------------------------------------------------------------------

SignatureProbs <- function(PredictedData,Testdata,FUN,threshold) {
  
  error <- threshold/100
  
  signatureInd <- list()
  for (col in names(PredictedData)) {
    print(col)
    measure <- FUN(PredictedData[[col]])
    print(measure)
    l <- measure * (1 - error)
    print("l")
    print(l)
    u <- measure * (1 + error)
    print("u") 
    print(u)
    
    print(which(names(PredictedData)==col))
    print(c(which((l)<=PredictedData[[col]] & PredictedData[[col]] <=u)))
    signatureInd[[which(names(PredictedData)==col)]]<-c(which((l)<=PredictedData[[col]] & PredictedData[[col]] <=u))
    
    # SignatureProbsOutput[which(names(PredictedData)==col)] <- c(signatureInd)
    
  }
  #return(signatureInd)
  subsetDataframe <- list()
  
  output <-signatureInd #SignatureProbs(TestmyTestSigGSE6791Model,myMax,1)
  for( i in 1:length(output)){
    
    #subsetDataframe[[i]]<-data.frame(myTestSigGSE6791)[c(output[[i]]),]
    subsetDataframe[[i]]<- data.frame(Testdata)[c(output[[i]]),]
    
  }
  
  ClusterSignatureData<-ldply(subsetDataframe)
  return(ClusterSignatureData)
}


#-----------------------------------------------------------------------------------
######################  Printing boolean formula
#-----------------------------------------------------------------------------------

boolForm <- function(df)
{
  
  for(r in 1:nrow(df)) {
    t<-df[r,]
    lit <- list()
    
    for(i in 1:length(t)) 
    {
      if(i!=length(t))
      {     
        if(t[i]==0)
        {
          lit[i]<- paste0(colnames(df)[i],'\' * ')
          cat(paste0(colnames(df)[i],'\' * '))
        }  else{
          lit[i]<- paste0(colnames(df)[i],' * ')
          cat(paste0(colnames(df)[i],' * '))
        }
      }else
      {if(t[i]==0)
      {
        lit[i]<- paste0(colnames(df)[i],'\' ')
        cat(paste0(colnames(df)[i],'\' '))
      }  else{
        lit[i]<- paste0(colnames(df)[i])
        cat(paste0(colnames(df)[i]))
      }
      }
    }
    if(r!=nrow(df))
      cat(" + ")
  }
  
  
  # print(unlist(lit))
  
  # print(unlist(strsplit(as.character(unlist(lit)),",")))
}


#---------------------------------------------------------------------------------------------
######################  Counting the truth table boolean vectors appearing in our data
#---------------------------------------------------------------------------------------------

CalFreqfun <- function(x.1,x.2,columns,diseaseColumn){
  
  x.11<- x.1[,columns]
  x.22<- x.2[,columns]
  
  x.1p <- do.call("paste", x.11)
  x.2p <- do.call("paste", x.22)
  data.frame(x.1[x.1p %in% x.2p,])
  trans1 <- t(x.1[x.1p %in% x.2p,])
  print("printing transpose")
  print(trans1)
  #print(row.names(trans1))
  a<- which(row.names(trans1)=="Class")
  print(a)
  b<- which(row.names(trans1)=="freq")
  print(b)
  print("printing only two rows")
  print(trans1[c(a,b),,drop=F])
  #tempDf <- data.frame(matrix(nrows = nrows(x.2),ncol = 4))
  
  df<-trans1[c(a,b),,drop=F]
  # colnames(df) <- df[c(which(row.names(df)=="Class")),,drop=F]
  # df<-df[-c(which(row.names(df)=="Class")),,drop=F]
  # df
  return(df)
}




#---------------------------------------------------------------------------------------------
######################  Systematic partition of training validation data
#---------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------
#                       Loading data: (No need to run these lines if the trainng and test data are already created.)
#----------------------------------------------------------------------------------------------------------------------------

FullGeneList <- c("MMP1", "MYO1B","LAPTM4B", "MAL", "KRT4","MYO10", "SPP1", "EXT1", "HPGD",  "MGST2", "AIM1")


# Loading the bigdata

# This data are already re-scaled. These data are generated from the "DFNormalisedCombinedData" obtained from 
# DataProcessing.R
Bigdata <- read.csv2("C:/Users/cpanchal/Desktop/GitHub Code Material/Big DataV2.csv")



DisjointScaledBigdata <- DisjontSets(Bigdata,"Class")
NewDisjointScaledBigdata <- ldply(DisjointScaledBigdata, data.frame)
rownames(NewDisjointScaledBigdata) <- NULL
categories <- c(levels(NewDisjointScaledBigdata$Class))
write.csv2(NewDisjointScaledBigdata, file = "NewDisjointScaledBigdata.csv",col.names = FALSE)



#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Select data from the categores
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

dfCat1 <- NewDisjointScaledBigdata[which(NewDisjointScaledBigdata$Class==categories[1]),]
dfCat1$Class <- factor(dfCat1$Class) 
dfCat2 <- NewDisjointScaledBigdata[which(NewDisjointScaledBigdata$Class==categories[2]),]
dfCat2$Class <- factor(dfCat2$Class)
dfCat3 <- NewDisjointScaledBigdata[which(NewDisjointScaledBigdata$Class==categories[3]),]
dfCat3$Class <- factor(dfCat3$Class)
dfCat4 <- NewDisjointScaledBigdata[which(NewDisjointScaledBigdata$Class==categories[4]),]
dfCat4$Class <- factor(dfCat4$Class)

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Ramndomly select  Training and validation from this function. We use ration of 60:40.
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

TrainValidata<-TrainValidationData(dfCat1,dfCat2,dfCat3,dfCat4,0.60)
NewTrainingDatasets <-  data.frame(TrainValidata$Train)
rownames(NewTrainingDatasets) <- NULL
NewTestingDatasets <- data.frame(TrainValidata$Test)
rownames(NewTestingDatasets) <- NULL



#----> Make sure that the data Class are trimed.
#----> If there is a space If the text column is not trimmed then we trim it.
#----> We order data according to the Class.

NewTrainingDatasets$Class<-as.factor(trimws(NewTrainingDatasets$Class, which = "both"))
NewTestingDatasets$Class<-as.factor(trimws(NewTestingDatasets$Class, which = "both"))


NewTrainingDatasets<-NewTrainingDatasets[order(NewTrainingDatasets$Class),]
NewTestingDatasets<- NewTestingDatasets[order(NewTestingDatasets$Class),]


#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# All the subsets of the significant genes  are computed.
# Significant Genes = FullGeneList = c("MMP1", "MYO1B","LAPTM4B", "MAL", "KRT4","MYO10", "SPP1", "EXT1", "HPGD",  "MGST2", "AIM1")
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# From the generated powersets we computer accuracy for each subsets of specific size. 
# The function "SubsetAccuracyFile" generates the .csv file containg results in the form of 
# c("Accuracy", "subset").
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  setwd("C:/Users/cpanchal/Desktop/GitHub Code Material/MLR result/Datasets")
 
  write.csv2(NewTrainingDatasets,file = "NewTrainingDatasets.csv",col.names = FALSE)
  write.csv2(NewTestingDatasets,file = "NewTestingDatasets.csv",col.names = FALSE)
  setwd("C:/Users/cpanchal/Desktop/GitHub Code Material/MLR result/Results")
  
  genes<- FullGeneList #colnames(NewTrainingDatasets)[3:ncol(NewTrainingDatasets)-1]
  genes_num <- as.numeric(factor(genes))
  genesDataframe<-data.frame(genes,genes_num)
  genePowerset <- powerset(genes_num)

  
# ----------------------------------------------------------------------------------------------------------------------------------------------------
# +  Following code calculates accuracies for each subset and selects a subset with maximum accuracy in each size group.
# ----------------------------------------------------------------------------------------------------------------------------------------------------
  
#  n = 3;
  
  
  for(n in 3:length(genes))
  {
    df_total<-SubsetAccuracyFile(genePowerset,genesDataframe,n,NewTrainingDatasets,NewTestingDatasets)
  }
     if(n>=length(genes)) 
       
      {
    
      filelist <- lapply(lapply(dir(), read.csv2),function(x) data.frame(x))
      fileDflist <- list()
      LengthSubsets <- c()  
      
      for(i  in 1:length(filelist)) {
        dfl <- data.frame(filelist[i])
        print(colnames(dfl))
        dfl$X <- NULL
        # Chrsub<- lapply(lapply(lapply(dfl$Subset, function(x) as.character(x)), function(x) strsplit(x,",")),unlist)
        # dfl$Chrsub <- Chrsub
        # dfl$Subset <- NULL
        writeDf <-data.frame(dfl[which(dfl$accuracy == max(dfl$accuracy)), ])
        
        if (nrow(writeDf) != 0)
        {
          print(nrow(writeDf))
          l <- length(unlist(strsplit(as.character(writeDf$Subset[1]), ",")))
          print("Length of the subset is is :")
          print(l)
          LengthSubsets[i] <- l
          
          #fname <- paste0("C:/Users/cpanchal/Desktop/Folders_n_Files/Head an neck cancer/Logistic regression in R/Train_Validation_Combined/set 2/requiredSubsize.", l, ".csv")
          #write.csv2(as.data.frame(writeDf), fname, row.names = FALSE)
          
          fileDflist[[l]] <- writeDf
        }
        
      }
      fileDflist
      
      filename = paste0("NonBinarisedSubsetResult",i,".txt")
      sink(filename)
      combinedResult <- do.call("rbind",fileDflist)
      rownames(combinedResult)<-NULL
      combinedResult <- data.frame(combinedResult)
      cat("\n","--------------------------------------------------------------------------------------","\n")
      print("Subsets of different sizes with maximum accuracy")
      cat("\n","--------------------------------------------------------------------------------------","\n")
      print(combinedResult)
      
      # RequiredSubset <- combinedResult[which(combinedResult$accuracy>=90),]
      # cat("\n","--------------------------------------------------------------------------------------","\n")
      # print("A subset with 90% accuracy")
      # cat("\n","--------------------------------------------------------------------------------------","\n")
      
      #print(RequiredSubset)
      
      RequiredSubsetMax <- combinedResult[which(combinedResult$accuracy==max(combinedResult$accuracy)),]
      cat("\n","--------------------------------------------------------------------------------------","\n")
      print("A subset with Maximum accuracy..")
      cat("\n","--------------------------------------------------------------------------------------","\n")
      
      print(RequiredSubsetMax)
      
      sink()
    }
    #View(df_total)
  
  
#}
  
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Step 7: The decided subset:  c("MGST2","AIM1","MMP1").
# Next we generate an artificial test data, a Truth table of size 3
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


GeneList1 <- c("MGST2","AIM1","MMP1") # We pick this  subset  from the collected results.


names(GeneList1) <- t(GeneList1)
BooleaDf <- data.frame(t(GeneList1))

n = length(GeneList1)
rows = 2 ^ n 
df <- matrix(data=NA,ncol =n , nrow=rows,byrow=TRUE)
for (i in 1 : rows) {
  
  df[i,] <- sapply((n-1):0, function(x,y) c(as.integer((y/(2 ** x))%%2)), y = (i-1))
  cat("\n")
}
df <- data.frame(df)
colnames(df) <- colnames(BooleaDf)
BooleaDf <- BooleaDf[-c(1),]
l <- list(BooleaDf,data.frame(df))
GeneTruthtable <- do.call(rbind.fill, l)
GeneTruthtable<-sapply(GeneTruthtable, as.numeric)  #...Converting data frame into numeric.
colnames(GeneTruthtable) <- gsub("^X.(.*)\\..*", "\\1",  colnames(GeneTruthtable))

GeneTruthtable<- data.frame(GeneTruthtable,row.names = NULL) 
print("Jump to step 10. Since we dont do predictions on boolean vectors using MULTINOM")



#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Step 10:  Combining training and validation data and Ordering them according to the Class column:
# Deriving boolean formulation: Through  Counting of truth table's boolean vectors  into the combined data.
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

BigdataToBinarise <- data.frame("Sample" = Bigdata$Samples, Bigdata[,GeneList1], "Class"=Bigdata$Class)
BigBin <- Bindata(BigdataToBinarise,2,ncol(BigdataToBinarise)-1)

BigData <- BigBin
SelectedGenes <- c(colnames(GeneTruthtable))

SelectedBigData <- BigData[,c(colnames(GeneTruthtable),"Class")]
TestGeneTruthtable <- GeneTruthtable[,-c(which(colnames(GeneTruthtable)=="myTestresultsClass"))]

SelectedBigData

library(plyr)
library(dplyr)
FreqRes<- plyr::count(SelectedBigData)
FreqRes <- FreqRes[order(FreqRes$freq),]

write.csv2(FreqRes,"CombinedDataCount.csv",col.names = FALSE)
freqDf= data.frame(matrix(ncol= ncol(FreqRes),nrow=0))
colnames(freqDf)<-colnames(FreqRes)

rownames(freqDf) <- NULL
FreqRes.1 <- data.frame(FreqRes[,c(SelectedGenes)])


# Instead of result we will use only normal GeneTruthTable
GeneTruthtable.1 <- data.frame(GeneTruthtable)


df0 <- data.frame()
colnames(df0)<- paste(unique(freqDf$Class))



for(i in 1:nrow(GeneTruthtable.1)) {
  df1<-CalFreqfun(FreqRes,GeneTruthtable.1[i,],c(SelectedGenes),unique(FreqRes$Class))
  colnames(df1)<- df1[c(1),,drop=F]
  df1<-df1[-c(1),,drop=F]
  print(data.frame(df1))
  #GeneTruthtable.2[i,c(colnames(df1))] <- df1
  df0<- smartbind(df0,df1)

  
}
df0 <- df0[-1,]
rownames(df0)<-NULL
GeneTruthtable.2 <- data.frame(cbind(GeneTruthtable.1,df0))
write.csv2(GeneTruthtable.2,"CountBoolvectorInCombineData.csv",col.names = FALSE)

#write.csv2(GeneTruthtable.2,"countedGeneTruthtable.csv")

df2<- data.frame(matrix(nrow = nrow(df0),ncol = 1))

for(i in 1:nrow(df0)) {
    df2[i,] <- sum(as.numeric(as.vector(df0[i,])),na.rm = TRUE)
}

colnames(df2) <- c("Total Vector Count")

GeneTruthtable.3 <- smartbind(GeneTruthtable.2,df2)

df3 <- data.frame(matrix(nrow = nrow(df0),ncol = ncol(df0)))
colnames(df3) <- colnames(df0)

df4 <- data.frame(matrix(nrow = nrow(df0),ncol = ncol(df0)))
colnames(df4) <- colnames(df0)

df5 <- data.frame(matrix(nrow = nrow(df0),ncol = ncol(df0)))
colnames(df5) <- colnames(df0)



for (i in 1:length(categories)) {
  df3[,c(colnames(df3)[i])] <- ifelse(is.na(as.numeric(df0[,c(colnames(df0)[i])]))==TRUE, NA, as.numeric(df0[,c(colnames(df0)[i])])/df2$`Total Vector Count`)
  df4[,c(colnames(df4)[i])]<-ifelse(is.na(as.numeric(df0[,c(colnames(df0)[i])]))==TRUE, NA, as.numeric(df0[,c(colnames(df0)[i])])/sum(as.numeric(df0[,c(colnames(df0)[i])]),na.rm = TRUE))
  df5[,c(colnames(df4)[i])]<-ifelse((is.na(as.numeric(df3[,c(colnames(df3)[i])]))==TRUE | is.na(as.numeric(df4[,c(colnames(df4)[i])]))==TRUE ), NA, as.numeric(df4[,c(colnames(df4)[i])]) * as.numeric(df3[,c(colnames(df3)[i])]))
  
}

colnames(df2)<-paste0(colnames(df2), "_counts")
colnames(df3)<-paste0(colnames(df3), "_GeneralFreq")
colnames(df4)<-paste0(colnames(df4), "_Prob")
colnames(df5)<-paste0(colnames(df5), "_Product")

GeneTruthtable.3 <- cbind(GeneTruthtable.2,df2,df3,df4)
write.csv2(GeneTruthtable.3,"Results to Analyse/L3CalcBoolvectorInCombineData.csv",col.names = FALSE)

#HighestValues <- apply(df4, 2, max,na.rm=T)
#HighestValuesThreshold <- 0.75* HighestValues

for(i in 1:length(categories)) {
 
  colID <- grep(categories[i],colnames(df4))
  a <-  max(df4[,c(colID)],na.rm=T) # HighestValue
  b <- 0.75* a # HighestValuesThreshold
  c <- max(0.25,b)
  filename = paste0(categories[i],".txt")
  
  sink(filename)
  SigMat <- data.frame(GeneTruthtable.1[c(which(c <= df4[,c(colID)] & a >= df4[,c(colID)])),])
  indx <- sapply(SigMat, is.factor)
  SigMat[indx] <- lapply(SigMat[indx], function(x) as.numeric(as.character(x)))
  colnames(SigMat) <-as.factor(trimws(colnames(SigMat), which = "both"))
  print(SigMat,row.names = FALSE)
  print(paste0("The boolean signature for the category: ", paste0(categories[i])),row.names = FALSE)
  boolForm(SigMat)
  sink()
  
}



# ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    
#Ploting data
# ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    ☆  ❋  ☆  ❋    



CombBigData <- data.frame(rbind(NewTrainingDatasets,NewTestingDatasets))

library(scales)
library(reshape)
library(ggplot2) 
meltData <- melt(NewDisjointScaledBigdata)


ggplot(meltData,aes(x = Genes, y =  Expression_Values,fill = Category)) + 
geom_bar(position = "fill", stat = "identity") + 
ggtitle("Gene expression in each category") + scale_y_continuous(limits = c(-1,1)) 

#______________________________________________________
# Confusion matrix, Accuracy and  Classification plots:
#______________________________________________________

# result <- resA # Assign a result to resA or res. resA stands for non-binarised data.
# 
# comparisition_matrix <- ftable(result$predicted, result$Numbered)
# accuracy <- 100* (sum(diag(comparisition_matrix)) / length(result$predicted))
# accuracy
# 
# Plotdata = data.frame(result$out,result$predicted)
# names(Plotdata) = c("Actual", "Predicted") 
# 
# #compute frequency of actual categories
# actual = as.data.frame(table(Plotdata$Actual))
# names(actual) = c("Actual","ActualFreq")
# 
# #build confusion matrix
# confusion = as.data.frame(table(Plotdata$Actual, Plotdata$Predicted))
# names(confusion) = c("Actual","Predicted","Freq")
# 
# #calculate percentage of test cases based on actual frequency
# confusion1 = merge(confusion, actual, by=c("Actual","Actual"))
# confusion1$Percent = confusion1$Freq/confusion1$ActualFreq*100
# 
# tile <- ggplot() +
#   geom_tile(aes(x=Actual, y=Predicted,fill=confusion1$Percent),data=confusion1, color="black",size=0.1) +
#   labs(x="Actual",y="Predicted")
# tile = tile + geom_text(aes(x=Actual,y=Predicted, label=sprintf("%.1f", confusion1$Percent)),data=confusion1, size=3, colour="black") +
#   scale_fill_gradient(low="light yellow",high="green")
# 
# tile = tile + geom_tile(aes(x=Actual,y=Predicted),data=subset(confusion1, as.character(Actual)==as.character(Predicted)), color="black",size=0.3, fill="black", alpha=0) 
# 
# #render
# tile

#write.csv2(SignatureProbs(TestmyTestSigGSE6791Model,myMax,1), file =  "ClusterSignatureData.csv", col.names = FALSE)
#View(ClusterSignature)


#output <-SignatureProbs(TestmyTestSigGSE6791Model,myMax,1)
#subsetDataframe <- list()
#subsetDataframe <- vector("list",length(output))
#for( i in 1:length(output)){
# subsetDataframe[[i]]<-data.frame(myTestSigGSE6791)[c(output[[i]]),]
#}
#library(plyr)
#ClusterSignatureData<-ldply(subsetDataframe)

# Function to generate a truth table



# Calculating accuracy
# sink("accuracy.txt")
# myTrain <- BinariedTrainingDatasets
# myTest<- BinariedTestingDatasets
# 
# myTrainModel<-multinom(Class ~ MMP1 + MYO1B +  MAL + MYO10 + SPP1 , data = myTrain)
# 
# myTestresultsClass<-predict(myTrainModel,data.frame(myTest) , type = "Class")
# myTestresultsPorbs<-predict(myTrainModel,data.frame(myTest) , type = "probs")
# 
# myTest$PredictedClass <- myTestresultsClass
# myTest$NumberedClass <-  c(factor(myTest$Class))
# 
# #length(which(myTest$Class == myTest$PredictedClass))
# 
# result <- myTest # Assign a result to resA or res. resA stands for non-binarised data.
# 
# comparisition_matrix <- ftable(result$Class, result$PredictedClass)
# comparisition_matrix 
# accuracy <- 100* (sum(diag(comparisition_matrix)) / length(result$PredictedClass))
# print("Accuracy in %")
# accuracy
# sink()

