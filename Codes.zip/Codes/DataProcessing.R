install.packages("R.utils")
install.packages("dplyr")
install.packages(c("matrixStats", "Hmisc", "splines", "foreach", "doParallel", "fastcluster", "dynamicTreeCut", "survival"))
install.packages("WGCNA")
install.packages("dynamicTreeCut")
install.packages("fastcluster")
source("http://www.bioconductor.org/biocLite.R")
biocLite("GEOquery")
biocLite("GEOmetadb")                      # install one or more specific packages and upgrade all currently installed packages
biocLite(c("limma", "GenomicRanges"))                  # affy :  Loading raw data
biocLite(c("affy","annotate"))    # Inorder to use Jetset package
biocLite(RSQLite)
biocLite(c("hgu133a.db","hgu133plus2.db","hgu95av2.db","u133x3p.db"))
biocLite("hugene10sttranscriptcluster.db")
biocLite("hugene10stprobeset.db")
install.packages("DBI")
install.packages("annotate")
install.packages("XML")
biocLite("org.Hs.eg.db")
biocLite(c("GO.db", "preprocessCore", "impute")) 
biocLite("RDAVIDWebService")
#----------------------------------------------------------------------------------------------------------------------#
#----------------------------------------------------------------------------------------------------------------------#

library(Biobase)
library(GEOquery)
library(org.Hs.eg.db)
library(RSQLite)
library(GEOmetadb)
library("jetset", lib.loc="~/R/R-3.3.1/library")
library("hgu133a.db")
library("hgu133plus2.db")
library("hgu95av2.db")
library("u133x3p.db")
library("hugene10sttranscriptcluster.db")
library("hugene10stprobeset.db")
library(affy)
library(gcrma)
library(XML)
library("annotate")
library(WGCNA)
library(RDAVIDWebService)
library(annotate)
memory.size(max = TRUE)
library(clusterSim)
library(gtools)
#----------------------------------------------------------------------------------------------------------------------#
# The following part of the code downloads the data and the plateform information. Here we also try to find gene association for each probes.
#----------------------------------------------------------------------------------------------------------------------#

# Mention the GEO series accession number to download e.g GSE6791. 
# GSEMatrix = FALSE will donwload the data in soft format. 

path = "C:/Users/cpanchal/Desktop/GitHub Code Material/DataDownloaded"
FileName = "GSE686"
GSEData <- getGEO(FileName,destdir = path, GSEMatrix = FALSE, getGPL = FALSE)
GeoSeries_NMAT <- getGEO(filename = paste0(path,"/",FileName,".soft.gz"), GSEMatrix = FALSE, getGPL = FALSE)

Meta(GeoSeries_NMAT)$platform_id

# Check the columns names of the data matrix.
print("First check the column names of the table and then proceed.")
tb <- Table(GPLList(GeoSeries_NMAT)[[1]])
colnames(tb)
x <- NULL
x <- readline("First check the column names and change wherever needed.Have you checked the column names ? y/n  ")

  
  ID <- Table(GPLList(GeoSeries_NMAT)[[1]])$ID
  Gene.Symbol<- Table(GPLList(GeoSeries_NMAT)[[1]])$"Gene Symbol"
  
  GB_ACC<- Table(GPLList(GeoSeries_NMAT)[[1]])$"GB_ACC" 
  
  # There is a way to find out associated gene names from the ENTREZ_GENE ID. In the data wherever there is an entrez gene id the gene name is already available.
  
  ENTREZ_GENE_ID<- Table(GPLList(GeoSeries_NMAT)[[1]])$"ENTREZ_GENE_ID"
  SPOT_ID<- Table(GPLList(GeoSeries_NMAT)[[1]])$"SPOT_ID"




DataMAT <- do.call('cbind',lapply(GSMList(GeoSeries_NMAT),function(x) 
{tab <- Table(x)
IDmatch <- match(ID,tab$ID_REF)
return(tab$VALUE[IDmatch])
}))
setwd("C:/Users/cpanchal/Desktop/GitHub Code Material/DataDownloaded")
data<-data.frame(ID,Gene.Symbol,GB_ACC,ENTREZ_GENE_ID,SPOT_ID,DataMAT)
write.table(data, file = paste0(FileName,"GeneExpr",".txt"))
write.csv2(read.table(paste0(FileName,"GeneExpr",".txt")), file=paste0(FileName,"GeneExpr",".csv"))

# Reading the csv file and taking median value of each rows.

View(read.csv2(file=paste0(FileName,"GeneExpr",".csv")))

#----------------------------------------------------------------------------------------------------------------------#
# The probes without geen association could be used in the following code and get the associated Gene mapping from the 
# followng downloaded databases.
#----------------------------------------------------------------------------------------------------------------------#

# select(hgu133a.db, c("AFFX-r2-P1-cre-5_at"), c("SYMBOL","ENTREZID", "GENENAME"))
# select(hgu133plus2.db, c("AFFX-r2-P1-cre-5_at"), c("SYMBOL","ENTREZID", "GENENAME"))
# select(u133x3p.db, c("AFFX-r2-P1-cre-5_at"), c("SYMBOL","ENTREZID", "GENENAME"))
# select(hgu95av2.db, c("AFFX-r2-P1-cre-5_at"), c("SYMBOL","ENTREZID", "GENENAME"))
# 
# #----------------------------------------------------------------------------------------------------------------------#
# # This part of the code just collects the information of probes from different sources.
# # Not necessary to run this part.
# #----------------------------------------------------------------------------------------------------------------------#
# 
# #names of the columns in the database.
# columns(hgu95av2.db)
# ## List the possible values for keytypes
# keytypes(hgu95av2.db)
# ## get some values back
# keys <- keys(hgu95av2.db)
# #select(hgu95av2.db, keys=keys, columns=c("SYMBOL","PFAM"), keytype="PROBEID")
# 
# ProbeGene_hgu133plus2<-select(hgu133plus2.db, keys(hgu133plus2.db,keytype = "PROBEID"), columns=c("SYMBOL","UNIGENE","ENTREZID"))
# ProbeGene_u133x3p<-select(u133x3p.db, keys(u133x3p.db,keytype = "PROBEID"), columns=c("SYMBOL","UNIGENE","ENTREZID"))
# ProbeGene_hgu133a<-select(hgu95av2.db, keys(hgu133a.db,keytype = "PROBEID"), columns=c("SYMBOL","UNIGENE","ENTREZID"))
# ProbeGene_hgu95av2<-select(hgu95av2.db, keys(hgu95av2.db,keytype = "PROBEID"), columns=c("SYMBOL","UNIGENE","ENTREZID"))
# 
# 
# write.csv2(ProbeGene_hgu133a,file = "ProbeGene_hgu133a.csv")
# write.csv2(ProbeGene_hgu133plus2,file = "ProbeGene_hgu133plus2.csv")
# write.csv2(ProbeGene_u133x3p,file = "ProbeGene_u133x3p.csv")
# write.csv2(ProbeGene_hgu95av2,file = "ProbeGene_hgu95av2.csv")
# 

#----------------------------------------------------------------------------------------------------------------------#
# In the part of the code we aggregate the probes with same gene association.
# In some probes the gene symbols are missing but ids like ENTREZ_GENE_ID are available.
# We use the web service called "DAVID" to find the gene symbols for such kind of probes using the ENTREZ_GENE_ID. 
#----------------------------------------------------------------------------------------------------------------------#

# Aggregating Probe Genes

setwd("C:/Users/cpanchal/Desktop/GitHub Code Material/Aggregated")
myData<-read.table(file=paste0("C:/Users/cpanchal/Desktop/GitHub Code Material/DataDownloaded/",FileName,"GeneExpr.txt"),header = T)

AggregatingProbes <- function(myData,FileName) {
  
  ids<-which((myData$Gene.Symbol==""|is.null(myData$Gene.Symbol)|is.na(myData$Gene.Symbol)) & (myData$ENTREZ_GENE_ID=="" |is.na(myData$ENTREZ_GENE_ID) ) )
 
  if(length(ids)!=0)
  {
    myDataFiltered <- myData[-ids,]
    
  }else{
    myDataFiltered <- myData
  }
  
  
  if(length(myDataFiltered$Gene.Symbol) == 0)
  {
    print("We can take median of the data based on the GENE id and then proceed to DAVID for collecting gene symbols.")
    myDataFilted.med <- aggregate(.~ENTREZ_GENE_ID,data=myDataFiltered,median,na.rm = T)
    dim(myDataFilted.med)
   
   # setwd("C:/Users/cpanchal/Desktop/Folders_n_Files/Head an neck cancer/Processed data_R/Probe expression")
    myDataFilted.med<- data.frame(myDataFilted.med)
    myDataFilted.med$probes=NULL
    
    write.table(myDataFilted.med,file=paste0("Median",FileName,".txt"),row.names = FALSE)
    write.csv2(read.table(file = paste0("Median",FileName,".txt")),file=paste0("Median",FileName,".csv"),col.names = FALSE)
    
    #----------------------------------------------------------------------------------------------------------------------#
    #                               Using DAVID to get the associted gene symbols.
    #----------------------------------------------------------------------------------------------------------------------#
    ans <- readline(prompt="Collected Results from DAVID ? : (y/n)")
    if(ans == "y") {
    table_myDataFilted.med <-myDataFilted.med[,which(colnames(myDataFilted.med)=="ENTREZ_GENE_ID")]
    write.table(table_myDataFilted.med,file="Gene_ACC_ID.txt",col.names =c("ENTREZ_GENE_ID"),row.names = FALSE,quote = FALSE)
    
    #
    # This table is uploaded in DAVID website.: https://david.ncifcrf.gov/conversion.jsp?VFROM=NA
    # Names the result file obtained from  David as : "ResultsFromDavid.txt" and store in the directory.
    #
    
    df2<-read.delim(file="ResultsFromDavid.txt",sep="\t")
    write.table(df2[2:nrow(df2),c(1,2)],file="GeneIDGeneSymbol.txt",row.names = FALSE,col.names = c("ENTREZ_GENE_ID","genes"),quote = FALSE)
    
    myData_genesDavid <- read.table(file="GeneIDGeneSymbol.txt",col.names = c("ENTREZ_GENE_ID","genes"))
    myData_genesDavid <- myData_genesDavid[2:nrow(myData_genesDavid),]
    myData_genesDavid$Gene.Symbol<- toupper(myData_genesDavid$Gene.Symbol)
    #----------------------------------------------------------------------------------------------------------------------#
    #----------------------------------------------------------------------------------------------------------------------#
    
    # The gene symbols fetched from DAVID for the uploaded GENE IDS  are merged with the file containing only GENE ID and,
    # missing GENE symbols.
      DataFull<- merge(myDataFilted.med,myData_genesDavid,all=TRUE)
    }
    else {
      DataFull<- merge(myDataFilted.med,all=TRUE)
    }
    
    DataFull<- merge(myDataFilted.med,myData_genesDavid,all=TRUE)
    
    DataFull$probes=NULL
    DataFull$ENTREZ_GENE_ID=NULL
    indices<- which((is.na(DataFull$Gene.Symbol)| DataFull$Gene.Symbol =="" | is.null(DataFull$Gene.Symbol)))
    DataFull<-DataFull[-indices,]
    col_idx1 <- grep("genes",colnames(DataFull))
    DataFull<-DataFull[,c(col_idx1,(1:ncol(DataFull))[-col_idx1])]
    setwd("C:/Users/cpanchal/Desktop/GitHub Code Material/Aggregated/GeneExpressionData")
    
    write.table(DataFull,file=paste0("GeneExpression",FileName,".txt"),row.names = FALSE)
    write.csv2(read.table(file=paste0("GeneExpression",FileName,".txt")),file=paste0("GeneExpression",FileName,".csv"),col.names = FALSE)
  }
 else{
    DataFull <- myDataFiltered
 }
  # Removing unneccessary columns.
  DataFull$ENTREZ_GENE_ID <- NULL  #....DataFull$geneENTREZ_GENE_ID<-NULL
  DataFull$ID<-NULL
  DataFull$probesName<-NULL
  
  DataFull<-data.frame(DataFull)
  # We compute gene expression by computing the median for the rows with repeated gene symbols
  myData_Full.med <- aggregate(.~Gene.Symbol,data=DataFull,median, na.rm=TRUE,na.action=NULL)
  
  dim(myData_Full.med)
  #setwd("C:/Users/cpanchal/Desktop/Folders_n_Files/Head an neck cancer/Processed data_R/GeneExpressionData/Training data/GSE42743")
  myData_Full.med <- data.frame(myData_Full.med)
  
  
  write.table(myData_Full.med,file=paste0(FileName,"Aggregated",".txt"),row.names = FALSE)
  write.csv2(read.table(file=paste0(FileName,"Aggregated",".txt")),file=paste0(FileName,"Aggregated",".csv"),col.names = FALSE)
  
  return(myData_Full.med)
}

AggregatingProbes(myData, FileName)


#----------------------------------------------------------------------------------------------------------------------#
#----------------------------------------------------------------------------------------------------------------------#
#---------------------------------------- Process the files which are analysed with GEO2R------------------------------#
#-------------------------------------Here we find the significant genes for each data series--------------------------#
#----------------------------------------------------------------------------------------------------------------------#

FileName = "GSE23036"

getwd()

######## Training datasets ######## 


# Function finds the significant genes from the GEO2R analysis result. 
# GEO2R analysis gives genes sorted with their p-values.
# Run it for all the results files collected for all GSE series.

  
  SignificantGenes <- function (work.dir,GEOResultFile)
  {
    filepath = paste0(work.dir,"/",GEOResultFile)
    Pval <- read.table(file=filepath,header = TRUE)
    SigGene_SubsetFrame<- subset(data.frame(Pval), adj.P.Val<0.05)
    SigGenesExp <- SigGene_SubsetFrame[,which(colnames(SigGene_SubsetFrame)== "Gene.symbol")]
    significantGene <- paste0("SignGSE",GEOResultFile)
    write.table(SigGenesExp,file=significantGene,row.names = FALSE)
    return(SigGenesExp)
  }

setwd("C:/Users/cpanchal/Desktop/GitHub Code Material/Aggregated/SigGeneExpressionData")
work.dir <- "C:/Users/cpanchal/Desktop/GitHub Code Material/GEO2R data"
GEOResultFile <- paste0("GEO2R_analysis",FileName,".txt")
SignificantGenes(work.dir,GEOResultFile)


#----------------------------------------------------------------------------------------------------------------------#

SigGene_GSE6791 <- read.table(file= "SignGSEGEO2R_analysisGSE6791.txt",header = TRUE)
SigGene_GSE9844 <- read.table(file= "SignGSEGEO2R_analysisGSE9844.txt",header = TRUE)
SigGene_GSE31056 <- read.table(file = "SignGSEGEO2R_analysisGSE31056.txt",header = TRUE)
SigGene_GSE30784 <- read.table(file = "SignGSEGEO2R_analysisGSE30784.txt",header = TRUE)

SigGene_GSE2379 <- read.table(file = "SignGSEGEO2R_analysisGSE2379.txt",header = TRUE)
SigGene_GSE3524 <- read.table(file = "SignGSEGEO2R_analysisGSE3524.txt",header = TRUE)
SigGene_GSE6631 <- read.table(file = "SignGSEGEO2R_analysisGSE6631.txt",header = TRUE)
SigGene_GSE13601 <- read.table(file = "SignGSEGEO2R_analysisGSE13601.txt",header = TRUE)
SigGene_GSE23036 <- read.table(file = "SignGSEGEO2R_analysisGSE23036.txt",header = TRUE)


TotalSignificant <- Reduce(intersect, list(SigGene_GSE6791$x,SigGene_GSE9844$x,SigGene_GSE31056$x, SigGene_GSE30784$x,SigGene_GSE2379$x,SigGene_GSE3524$x,SigGene_GSE6631$x, SigGene_GSE13601$x,SigGene_GSE23036$x))


#Trainingdf<-Reduce(intersect, list(SigGene_GSE6791,SigGene_GSE9844,SigGene_GSE6791, SigGene_GSE6791))
#write.table(file="SignificantGenesTraining.txt",Trainingdf,quote = FALSE, sep = "\t", row.names = FALSE, col.names = TRUE)

#Validationdf<-Reduce(intersect, list(SigGene_GSE686,SigGene_GSE6631,SigGene_GSE13601,SigGene_GSE23036,SigGene_GSE3524,SigGene_GSE2379GPL91))
#write.table(file="SignificantGenesValidation.txt",Validationdf,quote = FALSE, sep = "\t", row.names = FALSE, col.names = TRUE)

# TotalSignificant<-intersect(Trainingdf,Validationdf)

write.table(file="C:/Users/cpanchal/Desktop/GitHub Code Material/Aggregated/SignificantGenesOverall.txt",TotalSignificant,quote = FALSE, sep = "\t", row.names = FALSE, col.names = TRUE)
#----------------------------------------------------------------------------------------------------------------------#
#----------------------------------------------------------------------------------------------------------------------#
FileName = "GSE13601"


# Reading from the file.

#----> TotalSignificant<- read.table(file = "C:/Users/cpanchal/Desktop/GitHub Code Material/Aggregated/SignificantGenesOverall.txt",header = TRUE)
#----> TotalSignificant<-t(TotalSignificant)

# For our analysis we are using : TotalSignificant <- c("MMP1", "MYO1B","LAPTM4B", "MAL", "KRT4","MYO10", "SPP1", "EXT1", "HPGD",  "MGST2", "AIM1")

TotalSignificant <- c("MMP1", "MYO1B","LAPTM4B", "MAL", "KRT4","MYO10", "SPP1", "EXT1", "HPGD",  "MGST2", "AIM1")

GEAggregatedFile <- read.table(file=paste0("C:/Users/cpanchal/Desktop/GitHub Code Material/Aggregated/",FileName,"Aggregated.txt"), header = TRUE)



if( "" %in% TotalSignificant)
{
  TotalSignificant <- TotalSignificant[-which(TotalSignificant=="")]
}

for (g in TotalSignificant)
{
  #print(g)
  write.table(subset(data.frame(GEAggregatedFile), GEAggregatedFile$Gene.Symbol==g),file="temp1.txt",append = TRUE, col.names = TRUE,row.names = FALSE)
}

SigGEAggregatedFile<-read.table(file="temp1.txt",header = TRUE)
SigGEAggregatedFile<-unique(SigGEAggregatedFile)

if("genes" %in% SigGEAggregatedFile$Gene.Symbol)
{
  SigGEAggregatedFile<-SigGEAggregatedFile[-which(SigGEAggregatedFile$Gene.Symbol=="genes"),]
}

file.remove("temp1.txt")
row.names(SigGEAggregatedFile)<-NULL
write.table(file=paste0("C:/Users/cpanchal/Desktop/GitHub Code Material/Aggregated/SigGeneExpressionData/SigGeneExpression",FileName,".txt"),data.frame(SigGEAggregatedFile), col.names = TRUE,row.names = FALSE)


#setwd("C:/Users/cpanchal/Desktop/Folders_n_Files/Head an neck cancer/Processed data_R/Analysis from GEO2R/SigGeneExprFiles/")
#AllSamples <- loadWorkbook("C:/Users/cpanchal/Desktop/Folders_n_Files/Head an neck cancer/Processed data_R/Analysis from GEO2R/SigGeneExprFiles/Samples and Disease status.xlsx") #,sheet = 1, head=TRUE)


AllSamplesDiseaseStatus <- read.csv2(file= "C:/Users/cpanchal/Desktop/GitHub Code Material/Samples and Disease status.csv", header = TRUE)

dfAllSamples<-data.frame(AllSamplesDiseaseStatus)
dfSigFileGSE<- read.table(file=paste0("C:/Users/cpanchal/Desktop/GitHub Code Material/Aggregated/SigGeneExpressionData/SigGeneExpression",FileName,".txt"),header = TRUE)
dfSigFileGSESamples<-data.frame(t(dfSigFileGSE))
#write.table(file="dfsigGSE23036Samples.txt",dfSigFileGSESamples,row.names = TRUE,col.names = FALSE)

indexList<- list()

if(file.exists("subsetdf.txt")){
  file.remove("subsetdf.txt")
  for (i in 1: length(row.names(dfSigFileGSESamples)))
  {
    indexList[[i]]<-grep(row.names(dfSigFileGSESamples)[i],dfAllSamples$Sample..geo.accession.)
    
    if(!is.null(indexList[[i]])){
      a<-which(colnames(dfAllSamples)=="Sample..geo.accession.")
      b<- which(colnames(dfAllSamples)=="Sample.source.name..Disease.status.")
      
      write.table(file="subsetdf.txt", dfAllSamples[indexList[[i]],c(a,b)],append = TRUE, col.names = TRUE,row.names = FALSE)
    }
  }
} else {
  for (i in 1: length(row.names(dfSigFileGSESamples)))
  {
    indexList[[i]]<-grep(row.names(dfSigFileGSESamples)[i],dfAllSamples$Sample..geo.accession.)
    
    if(!is.null(indexList[[i]])){
      a<-which(colnames(dfAllSamples)=="Sample..geo.accession.")
      b<- which(colnames(dfAllSamples)=="Sample.source.name..Disease.status.")
      
      write.table(file="subsetdf.txt", dfAllSamples[indexList[[i]],c(a,b)],append = TRUE, col.names = TRUE,row.names = FALSE)
    }
  }
}

dfsigGSEDisease <- read.table(file="subsetdf.txt",header = TRUE)
dfsigGSEDisease <- unique(dfsigGSEDisease)

row.names(dfsigGSEDisease)<- NULL


dfSigFileGSESamples<-dfSigFileGSESamples[-c(which(row.names(dfSigFileGSESamples)=="GB_ACC"),which(row.names(dfSigFileGSESamples)=="SPOT_ID")),]

dfSigFileGSESamplesDisease<- data.frame(t(cbind(dfSigFileGSESamples,dfsigGSEDisease)))


rownames(dfSigFileGSESamplesDisease)<- NULL

dfSigFileGSESamplesDisease<-dfSigFileGSESamplesDisease[-c(which(dfSigFileGSESamplesDisease$Gene.Symbol=="Sample..geo.accession.")),]
dfSigFileGSESamplesDisease<-dfSigFileGSESamplesDisease[-c(which(dfSigFileGSESamplesDisease$Gene.Symbol=="Gene.Symbol")),]

dfSigFileGSESamplesDisease<-dfSigFileGSESamplesDisease[c(which(dfSigFileGSESamplesDisease$Gene.Symbol=="Sample.source.name..Disease.status."),1:nrow(dfSigFileGSESamplesDisease)-1),]
row.names(dfSigFileGSESamplesDisease)<- NULL


write.table(file=paste0("C:/Users/cpanchal/Desktop/GitHub Code Material/Aggregated/SigGeneExpressionData/SampleDisease/SigGeneExpressionDisease",FileName,".txt"),dfSigFileGSESamplesDisease,col.names = TRUE,row.names = FALSE)


#----------------------------------------------- Data normalization (Data rescaling) -----------------------------------------------


setwd("C:/Users/cpanchal/Desktop/GitHub Code Material/Aggregated/SigGeneExpressionData/SampleDisease/")

GeneExpFiles <- list.files(path = ".", pattern = ".txt")
GenerateScaledData(GeneExpFiles)


GenerateScaledData <- function(Files) {
for(i in 1:length(Files)) {
  
  gexfile <- read.table(Files[i],header = TRUE)
  subPart <- gexfile[2:nrow(gexfile),2:ncol(gexfile)]
  numsubPart <- lapply(subPart, function(x) as.numeric(as.character(x)))
  normsubPart <- data.Normalization(data.frame(numsubPart), type="n3",normalization="raw")
  
  gexfile1 <- data.frame(smartbind(gexfile[1,],normsubPart))
  NormGexfile <- cbind(gexfile1,gexfile$Gene.Symbol)
  NormGexfile<- NormGexfile[,-c(1)]
  NormGexfile <- data.frame(NormGexfile[,c(ncol(NormGexfile),1:ncol(NormGexfile)-1)])
  rownames(NormGexfile) <- NULL
  colnames(NormGexfile) <- colnames(gexfile)
  
  dir.create("ScaledNormalised", showWarnings = FALSE)
  
  path = paste0("ScaledNormalised/",paste0("Normalised_",Files[i]))
  pathCSV = paste0("ScaledNormalised/",paste0("Normalised_",Files[i],".csv"))
  write.table(NormGexfile,file = path)
  write.csv2(NormGexfile,file=pathCSV,col.names = FALSE)
  
  }
  
}

# Following code will mearged all the normalised data in one file.

setwd(paste0(getwd(),"/","ScaledNormalised"))
NormalisedFiles <- list.files(path = ".", pattern = "txt$")
NormalisedCombinedData <- list()

NormalisedValidatation <- list()

for(i in 1:length(NormalisedFiles)) {
  
  NormalisedCombinedData[[i]] <- read.table(NormalisedFiles[i],header = TRUE)
  
  #NormalisedTraining[[i]] <- read.table(normFiles[i],header = TRUE)
  
}
DFNormalisedCombinedData <- data.frame(lapply(NormalisedCombinedData, smartbind))

#NormalisedTrainingDF <- data.frame(lapply(NormalisedTraining, cbind))

#setwd("C:/Users/cpanchal/Desktop/Folders_n_Files/Head an neck cancer/Processed data_R/Analysis from GEO2R/SigGeneExprFiles/Training/SigSampleDisease/GeneExpression/ScaledNormalised")

write.table(DFNormalisedCombinedData,file = "NormalisedCombinedData.txt",row.names = FALSE)

write.csv2(DFNormalisedCombinedData,file= "NormalisedCombinedData.csv",col.names = FALSE)
print("From this data, we generated files: Big DataV1.csv and Big DataV2.csv")

#-------------------------------------------------------------------------------------------------








